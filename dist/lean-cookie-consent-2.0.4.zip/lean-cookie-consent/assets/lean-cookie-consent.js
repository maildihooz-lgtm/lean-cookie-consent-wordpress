!(function () {
  "use strict";
  var script =
    document.currentScript ||
    (function () {
      var scripts = document.getElementsByTagName("script");
      return scripts[scripts.length - 1] || null;
    })();
  function fail(reason) {
    window.LeanCookieConsent = window.LeanCookieConsent || {};
    window.LeanCookieConsent.configError = reason || "config_fetch_failed";
  }
  function param(name, fallback) {
    try {
      var src = (script && script.src) || "";
      var value = new URL(src, window.location.href).searchParams.get(name);
      return value || fallback || "";
    } catch (e) {
      return fallback || "";
    }
  }
  var site = param("site", "").trim();
  var apiBase = param("api", "https://api.leancookieconsent.com").replace(
    /\/+$/g,
    "",
  );
  if (!site) {
    fail("missing_site_key");
    return;
  }
  fetch(apiBase + "/v1/config?site=" + encodeURIComponent(site), {
    method: "GET",
    credentials: "omit",
    cache: "default",
  })
    .then(function (response) {
      if (409 === response.status) {
        fail("tcf_not_supported_runtime_mode");
        return null;
      }
      if (!response.ok) {
        fail("config_http_" + response.status);
        return null;
      }
      return response.json();
    })
    .then(function (config) {
      if (!config) return;
      if (config.tcf && config.tcf.enabled) {
        fail("tcf_not_supported_runtime_mode");
        return;
      }
      !(function (e) {
        "use strict";
        if (e && !document.querySelector("[data-lean-cookie-platform]")) {
          var t,
            o,
            n,
            a = e.style || {},
            i = e.accent || "#075985",
            r = (function () {
              var t = e.supportedLanguages || ["en"],
                o = "";
              try {
                o =
                  new URLSearchParams(window.location.search).get("lang") || "";
              } catch (e) {}
              var n = "";
              try {
                n =
                  (document.documentElement && document.documentElement.lang) ||
                  "";
              } catch (e) {}
              for (
                var a = [
                    o,
                    n,
                    navigator.language || "",
                    (navigator.languages && navigator.languages[0]) || "",
                    e.defaultLanguage || "en",
                  ],
                  i = 0;
                i < a.length;
                i++
              ) {
                var r = String(a[i] || "")
                  .slice(0, 2)
                  .toLowerCase();
                if (t.indexOf(r) > -1) return r;
              }
              return e.defaultLanguage || "en";
            })(),
            l =
              (e.translations && e.translations[r]) ||
              (e.translations && e.translations.en) ||
              {};
          h("default", y(!1, !1)),
            (window.LeanCookieConsent = window.LeanCookieConsent || {}),
            (window.LeanCookieConsent.hasConsent = function (e) {
              return "technical" === e || "1" === d("lean_cookie_consent_" + e);
            }),
            (window.LeanCookieConsent.runAllowed = A),
            (window.LeanCookieConsent.openPreferences = E),
            (window.LeanCookieConsent.closePreferences = U),
            "loading" === document.readyState
              ? document.addEventListener("DOMContentLoaded", D)
              : D();
        }
        function c(e) {
          return l[e] || e;
        }
        function d(e) {
          for (
            var t = e + "=",
              o = document.cookie ? document.cookie.split(";") : [],
              n = 0;
            n < o.length;
            n++
          ) {
            var a = o[n].trim();
            if (0 === a.indexOf(t))
              return decodeURIComponent(a.substring(t.length));
          }
          return "";
        }
        function s(t, o, n) {
          var a = new Date();
          a.setTime(a.getTime() + 864e5 * n);
          var i =
            t +
            "=" +
            encodeURIComponent(o) +
            "; expires=" +
            a.toUTCString() +
            "; path=/; SameSite=Lax";
          "https:" === location.protocol && (i += "; Secure"),
            (document.cookie = i);
          var r = String(e.cookieDomain || "").toLowerCase(),
            l = String(location.hostname || "").toLowerCase();
          !r ||
            (l !== r && l.slice(-(r.length + 1)) !== "." + r) ||
            (document.cookie = i + "; domain=." + r);
        }
        function p(e) {
          var t = d("lean_cookie_visitor_id");
          return (
            t ||
              s(
                "lean_cookie_visitor_id",
                (t =
                  "undefined" != typeof crypto && crypto.randomUUID
                    ? crypto.randomUUID()
                    : String(Date.now()) + Math.random().toString(16).slice(2)),
                e,
              ),
            t
          );
        }
        function u(e) {
          return String(e || "").replace(/[&<>"']/g, function (e) {
            return {
              "&": "&amp;",
              "<": "&lt;",
              ">": "&gt;",
              '"': "&quot;",
              "'": "&#039;",
            }[e];
          });
        }
        function g(e, t) {
          return (e = String(e || "")), /^#[0-9a-f]{6}$/i.test(e) ? e : t;
        }
        function f(e) {
          if (!e) return "";
          try {
            var t = new URL(String(e), window.location.href);
            return "https:" === t.protocol ? t.href : "";
          } catch (e) {
            return "";
          }
        }
        function m(e) {
          return f(e) || location.origin + location.pathname;
        }
        function P() {
          return location.origin + location.pathname;
        }
        function k() {
          return "1" === d("lean_cookie_consent_analytics");
        }
        function b() {
          return "1" === d("lean_cookie_consent_marketing");
        }
        function x() {
          return "1" === d("lean_cookie_consent_saved");
        }
        function h(e, t) {
          (window.dataLayer = window.dataLayer || []),
            (window.gtag =
              window.gtag ||
              function () {
                window.dataLayer.push(arguments);
              }),
            window.gtag("consent", e, t);
        }
        function y(e, t) {
          return {
            ad_storage: t ? "granted" : "denied",
            ad_user_data: t ? "granted" : "denied",
            ad_personalization: t ? "granted" : "denied",
            analytics_storage: e ? "granted" : "denied",
            functionality_storage: "granted",
            security_storage: "granted",
          };
        }
        function v(t, o) {
          var n = [];
          return (
            (e.services || []).forEach(function (e) {
              ("technical" === e.category ||
                ("analytics" === e.category && t) ||
                ("marketing" === e.category && o)) &&
                n.push(e.id);
            }),
            n
          );
        }
        function _(e, t, o, n, a) {
          return (
            "technical" === e ||
            ("analytics" === e && n) ||
            ("marketing" === e && a) ||
            (!e && t && o.indexOf(t) > -1)
          );
        }
        function w(e, t) {
          var o = v(e, t);
          document
            .querySelectorAll(
              'script[type="text/plain"][data-lean-cookie-category],script[type="text/plain"][data-lean-cookie-service]',
            )
            .forEach(function (n) {
              if (
                _(
                  n.getAttribute("data-lean-cookie-category") || "",
                  n.getAttribute("data-lean-cookie-service") || "",
                  o,
                  e,
                  t,
                ) &&
                "1" !== n.getAttribute("data-lean-cookie-loaded")
              ) {
                for (
                  var a = document.createElement("script"), i = 0;
                  i < n.attributes.length;
                  i++
                ) {
                  var r = n.attributes[i],
                    l = r.name.toLowerCase(),
                    c = r.value || "";
                  if ("src" === l) {
                    var d = f(c);
                    d && a.setAttribute("src", d);
                  } else
                    "async" === l || "defer" === l || "nomodule" === l
                      ? a.setAttribute(l, "")
                      : "nonce" === l && /^[A-Za-z0-9+/_=-]{1,128}$/.test(c)
                        ? a.setAttribute("nonce", c)
                        : "integrity" === l &&
                            /^sha(256|384|512)-[A-Za-z0-9+/=]+$/.test(c)
                          ? a.setAttribute("integrity", c)
                          : "crossorigin" === l &&
                              /^(anonymous|use-credentials)$/.test(c)
                            ? a.setAttribute("crossorigin", c)
                            : "referrerpolicy" === l &&
                              /^(no-referrer|no-referrer-when-downgrade|origin|origin-when-cross-origin|same-origin|strict-origin|strict-origin-when-cross-origin|unsafe-url)$/.test(
                                c,
                              ) &&
                              a.setAttribute("referrerpolicy", c);
                }
                (a.type = "text/javascript"),
                  (a.text = n.text || n.textContent || ""),
                  n.setAttribute("data-lean-cookie-loaded", "1"),
                  n.parentNode.insertBefore(a, n.nextSibling);
              }
            }),
            document
              .querySelectorAll(
                "iframe[data-lean-cookie-src][data-lean-cookie-category],iframe[data-lean-cookie-src][data-lean-cookie-service]",
              )
              .forEach(function (n) {
                if (
                  _(
                    n.getAttribute("data-lean-cookie-category") || "",
                    n.getAttribute("data-lean-cookie-service") || "",
                    o,
                    e,
                    t,
                  ) &&
                  "1" !== n.getAttribute("data-lean-cookie-loaded")
                ) {
                  var a = f(n.getAttribute("data-lean-cookie-src") || "");
                  a &&
                    (n.setAttribute("src", a),
                    n.setAttribute("data-lean-cookie-loaded", "1"),
                    n.removeAttribute("data-lean-cookie-src"),
                    n.removeAttribute("aria-busy"));
                }
              });
        }
        function A() {
          var e = k(),
            t = b();
          h("update", y(e, t)), w(e, t);
        }
        function L() {
          if (t) {
            var e = t.querySelector('[data-lean-toggle="analytics"]'),
              o = t.querySelector('[data-lean-toggle="marketing"]');
            e && (e.checked = k()), o && (o.checked = b());
            var n = t.querySelector("[data-lean-status]");
            n &&
              (n.textContent = x()
                ? c("current_choices")
                    .replace("{analytics}", k() ? c("on") : c("off"))
                    .replace("{marketing}", b() ? c("on") : c("off"))
                : c("no_saved_choice"));
          }
        }
        function S(e, t) {
          return "reject_all" === e || "close_without_consent" === e
            ? "withdrawn"
            : t
              ? "updated"
              : "created";
        }
        function C(t, o, n) {
          var a = parseInt(e.expirationDays, 10) || 180,
            i = x(),
            q = v(t, o);
          s("lean_cookie_consent_saved", "1", a),
            s("lean_cookie_consent_version", e.bannerVersion || "", a),
            s("lean_cookie_consent_tech", "1", a),
            s("lean_cookie_consent_analytics", t ? "1" : "0", a),
            s("lean_cookie_consent_marketing", o ? "1" : "0", a),
            fetch(e.apiUrl, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                analytics: t ? "1" : "0",
                marketing: o ? "1" : "0",
                action: n || "save_preferences",
                event_type: S(n || "save_preferences", i),
                previous_consent: i ? "1" : "0",
                visitor_id: p(a),
                page_url: P(),
                services: q,
                source: "preference_center",
                policy_version: e.policyVersion || "",
                banner_version: e.bannerVersion || "",
                evidence_signature: e.evidenceSignature || "",
                r: r,
              }),
              keepalive: !0,
            }).catch(function () {}),
            h("update", y(t, o)),
            w(t, o),
            U();
        }
        function z(e, t, o, n, a) {
          return (
            '<label class="lcc-tg"><span><strong>' +
            u(t) +
            "</strong><small>" +
            u(o) +
            '</small></span><input type="checkbox" data-lean-toggle="' +
            u(e) +
            '" ' +
            (n ? "checked" : "") +
            " " +
            (a ? "disabled" : "") +
            ' aria-label="' +
            u(t) +
            ' consent"></label>'
          );
        }
        function E() {
          if (t) {
            (n = document.activeElement),
              L(),
              (t.hidden = !1),
              t.setAttribute("aria-hidden", "false");
            var e =
              t.querySelector("[data-lean-accept]") ||
              t.querySelector("[data-lean-close]");
            e && e.focus();
          }
        }
        function U() {
          if (t) {
            var e = n && document.contains(n) && !t.contains(n) ? n : o;
            t.contains(document.activeElement) &&
              (e && e.focus
                ? (function () {
                    try {
                      e.focus({ preventScroll: !0 });
                    } catch (t) {
                      e.focus();
                    }
                  })()
                : document.activeElement &&
                  document.activeElement.blur &&
                  document.activeElement.blur()),
              t.setAttribute("aria-hidden", "true"),
              (t.hidden = !0);
          }
        }
        function q(e) {
          if (t && !t.hidden && "Tab" === e.key) {
            var o = t
              ? Array.prototype.slice
                  .call(
                    t.querySelectorAll(
                      'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',
                    ),
                  )
                  .filter(function (e) {
                    return !!(
                      e.offsetWidth ||
                      e.offsetHeight ||
                      e.getClientRects().length
                    );
                  })
              : [];
            if (o.length) {
              var n = o[0],
                a = o[o.length - 1];
              e.shiftKey && document.activeElement === n
                ? (e.preventDefault(), a.focus())
                : e.shiftKey ||
                  document.activeElement !== a ||
                  (e.preventDefault(), n.focus());
            }
          }
        }
        function D() {
          var n;
          (i = g(i, "#075985")),
            (a.background = g(a.background, "#fff")),
            (a.text = g(a.text, "#1f2937")),
            (a.muted = g(a.muted, "#64748b")),
            (a.border = g(a.border, "#d9e1ea")),
            (a.font =
              ((n = a.font),
              (n = String(n || "")) && n.length <= 160 && !/[;{}<>]/.test(n)
                ? n
                : 'system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif'));
          var l =
              m(e.cookiePolicyUrl) +
              (m(e.cookiePolicyUrl).indexOf("?") > -1 ? "&" : "?") +
              "lang=" +
              encodeURIComponent(r),
            f =
              m(e.privacyPolicyUrl) +
              (m(e.privacyPolicyUrl).indexOf("?") > -1 ? "&" : "?") +
              "lang=" +
              encodeURIComponent(r),
            h = document.createElement("style");
          h.setAttribute("data-lean-cookie-platform", "style"),
            (h.textContent =
              ".lcc{position:fixed;inset:0;z-index:2147483000;display:grid;place-items:end center;padding:18px;background:rgba(15,23,42,.34);box-sizing:border-box;font-family:" +
              a.font +
              ";letter-spacing:-.011em;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility;color:" +
              a.text +
              "}.lcc[hidden]{display:none}.lcc *{box-sizing:border-box}.lcc :focus-visible,.lcc-ed:focus-visible{outline:3px solid #f59e0b;outline-offset:3px}.lcc-pa{width:min(960px,100%);max-height:calc(100vh - 36px);overflow:auto;padding:22px;border:1px solid " +
              a.border +
              ";border-radius:14px;background:" +
              a.background +
              ";box-shadow:0 20px 60px rgba(15,23,42,.28)}.lcc-he{display:grid;grid-template-columns:1fr auto;gap:14px;align-items:start}.lcc h2{margin:0;color:" +
              i +
              ";font-size:21px;line-height:1.25;letter-spacing:-.018em;font-weight:820}.lcc p{margin:10px 0 0;line-height:1.55;font-size:14.5px;color:#1f2937}.lcc a{color:" +
              i +
              ";font-weight:750;text-decoration:underline;text-underline-offset:3px}.lcc-cl{min-width:72px;height:38px;padding:0 12px!important;border-radius:999px!important;background:transparent!important;color:" +
              i +
              "!important;font-size:14px;line-height:1}.lcc-in{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(320px,.9fr);gap:18px;align-items:start;margin-top:10px}.lcc-li{display:flex;flex-wrap:wrap;gap:10px;margin-top:12px}.lcc-gr{display:grid;gap:10px}.lcc-tg{display:grid;grid-template-columns:1fr auto;gap:14px;align-items:center;padding:12px 13px;border:1px solid " +
              a.border +
              ";border-radius:10px;background:rgba(248,250,252,.78);text-align:left}.lcc-tg strong{display:block;margin:0 0 4px;font-size:14px}.lcc-tg small,.lcc-st{display:block;color:" +
              a.muted +
              ";font-size:13px;line-height:1.35}.lcc-tg input{width:20px;height:20px;accent-color:" +
              i +
              "}.lcc-ac{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:10px;margin-top:16px}.lcc button,.lcc-ed{min-height:42px;padding:0 17px;border:1px solid " +
              i +
              ";border-radius:999px;background:" +
              i +
              ";color:#fff;font-weight:760;cursor:pointer;letter-spacing:0}.lcc button.secondary{background:transparent;color:" +
              i +
              "}.lcc button[data-lean-deny]{background:" +
              i +
              ";color:#fff}.lcc-ed{position:fixed;left:14px;bottom:14px;z-index:2147482999;background:#fff;color:" +
              i +
              ";box-shadow:0 8px 24px rgba(15,23,42,.18)}@media(max-width:760px){.lcc{padding:8px;background:rgba(15,23,42,.22);place-items:end center}.lcc-pa{width:100%;max-height:min(76vh,560px);padding:13px;border-radius:12px;box-shadow:0 12px 36px rgba(15,23,42,.22)}.lcc-he{grid-template-columns:minmax(0,1fr) auto;gap:8px}.lcc h2{font-size:18px}.lcc p{font-size:13px;line-height:1.38;margin-top:6px}.lcc #lcc-de{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.lcc-st{font-size:12px!important}.lcc-cl{min-width:56px;height:32px;padding:0 9px!important;font-size:13px}.lcc-in{grid-template-columns:1fr;gap:10px;margin-top:8px}.lcc-li{gap:8px;margin-top:8px}.lcc-gr{gap:7px}.lcc-tg{padding:9px 10px;gap:10px;border-radius:9px}.lcc-tg strong{font-size:13px;margin-bottom:2px}.lcc-tg small{font-size:12px;line-height:1.25;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.lcc-tg input{width:18px;height:18px}.lcc-ac{display:grid;grid-template-columns:1fr;gap:8px;margin-top:10px}.lcc-ac button{min-height:38px;padding:0 10px;font-size:13px}.lcc-ed{left:8px;bottom:8px;min-height:36px;padding:0 12px}}"),
            document.head.appendChild(h),
            ((t = document.createElement("div")).className = "lcc"),
            t.setAttribute("data-lean-cookie-platform", "banner"),
            t.setAttribute("role", "dialog"),
            t.setAttribute("aria-modal", "true"),
            t.setAttribute("aria-hidden", "false"),
            t.setAttribute("aria-labelledby", "lcc-ti"),
            t.setAttribute("aria-describedby", "lcc-de lcc-st");
          var y,
            v,
            _ = (y = e.localizedContent || {})[r] ||
              y[e.defaultLanguage || "en"] || {
                heading: e.heading || "",
                policy: e.policy || "",
                categories: e.categories || {},
              },
            w = _.categories || e.categories || {};
          (t.innerHTML =
            '<div class="lcc-pa" data-lcc-pa><div class="lcc-he"><div><h2 id="lcc-ti">' +
            u(_.heading || e.heading) +
            '</h2><p id="lcc-de">' +
            u(_.policy || e.policy) +
            '</p><p class="lcc-st">' +
            u(c("close_keeps_necessary")) +
            '</p><p class="lcc-st" id="lcc-st" data-lean-status role="status" aria-live="polite"></p><div class="lcc-li"><a href="' +
            u(l) +
            '" target="_blank" rel="noopener noreferrer">' +
            u(c("cookie_policy")) +
            '</a><a href="' +
            u(f) +
            '" target="_blank" rel="noopener noreferrer">' +
            u(c("privacy_policy")) +
            '</a></div></div><button type="button" class="lcc-cl" data-lean-close>' +
            u(c("close")) +
            '</button></div><div class="lcc-in"><div></div><div><div class="lcc-gr">' +
            z("technical", c("technical"), w.technical || "", !0, !0) +
            z("analytics", c("analytics"), w.analytics || "", k(), !1) +
            z("marketing", c("marketing"), w.marketing || "", b(), !1) +
            '</div><div class="lcc-ac"><button type="button" data-lean-accept>' +
            u(a.acceptLabel || c("accept_all")) +
            '</button><button type="button" data-lean-deny>' +
            u(a.denyLabel || c("only_necessary")) +
            '</button><button type="button" class="secondary" data-lean-save>' +
            u(a.saveLabel || c("save_choices")) +
            "</button></div></div></div></div>"),
            document.body.appendChild(t),
            ((o = document.createElement("button")).type = "button"),
            (o.className = "lcc-ed"),
            o.setAttribute("aria-label", c("manage_cookie_preferences")),
            (o.textContent = c("cookie_settings")),
            document.body.appendChild(o),
            x() &&
              d("lean_cookie_consent_version") === (e.bannerVersion || "") &&
              (s(
                "lean_cookie_consent_saved",
                "1",
                (v = parseInt(e.expirationDays, 10) || 180),
              ),
              s("lean_cookie_consent_version", e.bannerVersion || "", v),
              s("lean_cookie_consent_tech", "1", v),
              s("lean_cookie_consent_analytics", k() ? "1" : "0", v),
              s("lean_cookie_consent_marketing", b() ? "1" : "0", v),
              p(v),
              (t.hidden = !0),
              t.setAttribute("aria-hidden", "true"),
              A()),
            L(),
            o.addEventListener("click", E),
            t
              .querySelector("[data-lean-close]")
              .addEventListener("click", function () {
                C(!1, !1, "close_without_consent");
              }),
            t.addEventListener("click", function (e) {
              e.target === t && C(!1, !1, "close_without_consent");
            }),
            document.addEventListener("keydown", function (e) {
              q(e),
                "Escape" === e.key &&
                  t &&
                  !t.hidden &&
                  C(!1, !1, "close_without_consent");
            }),
            t
              .querySelector("[data-lean-accept]")
              .addEventListener("click", function () {
                C(!0, !0, "accept_all");
              }),
            t
              .querySelector("[data-lean-deny]")
              .addEventListener("click", function () {
                C(!1, !1, "reject_all");
              }),
            t
              .querySelector("[data-lean-save]")
              .addEventListener("click", function () {
                C(
                  !!t.querySelector('[data-lean-toggle="analytics"]').checked,
                  !!t.querySelector('[data-lean-toggle="marketing"]').checked,
                  "save_preferences",
                );
              }),
            t.hidden || E();
        }
      })(config);
    })
    .catch(function () {
      fail("config_fetch_failed");
    });
})();
